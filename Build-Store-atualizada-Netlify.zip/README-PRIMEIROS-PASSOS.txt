BUILD STORE — COMEÇANDO PELO CELULAR

O QUE TEM NESTA PASTA
- public/index.html: estrutura da loja
- public/style.css: visual dark roxo
- public/products.js: cadastro dos produtos e preços
- public/app.js: filtros, carrinho e interações
- netlify.toml: configuração de publicação no Netlify

PUBLICAR PELO CELULAR
1. Extraia o ZIP no celular.
2. Abra https://app.netlify.com/ e crie sua conta.
3. Para publicar pelo celular, a opção mais simples é usar um repositório GitHub:
   - Abra https://github.com/ e crie uma conta ou entre.
   - Crie um repositório chamado build-store.
   - Envie os arquivos e pastas extraídos mantendo a estrutura.
   - No Netlify, escolha Add new project / Import an existing project.
   - Conecte o GitHub e selecione build-store.
   - O Netlify deve detectar a pasta public como diretório de publicação. Se pedir configuração, Publish directory: public. Não precisa de comando de build.
   - Clique em Deploy.
4. O Netlify fornecerá um endereço público para sua loja.

ADICIONAR SEUS PRODUTOS
1. No GitHub, abra public/products.js e toque no lápis para editar.
2. Altere nome, categoria, descrição e preço dos exemplos.
3. Para adicionar outro, copie um objeto completo e mude o id para um valor único.
4. Salve/commit. O Netlify publica a atualização automaticamente.
5. Para imagens, crie public/images e envie suas imagens. No produto, use image:"/images/minha-build.jpg".

IMPORTANTE SOBRE ARQUIVOS E PAGAMENTO
- Esta primeira versão NÃO cobra PIX e NÃO entrega arquivos automaticamente ainda.
- Para PIX automático é preciso integrar um provedor de pagamento com webhook.
- Nunca coloque token/chave secreta no código público.
- Não libere arquivos só porque alguém abriu uma página de sucesso.
- Mantenha os arquivos pagos em armazenamento privado e libere após confirmação real do pagamento.
- Use apenas builds e imagens que você tem direito de vender.
- Confira as regras do Roblox para venda e distribuição de modelos.

TESTE
Abra o endereço publicado, adicione produtos ao carrinho, atualize a página e confirme que o carrinho continua salvo.

PRODUTO JÁ CADASTRADO
- Run System — R$ 5,00 (aprox. US$ 0,90; valor ilustrativo, sujeito à cotação).
- Categoria: Sistemas.
- Formato do arquivo ainda não informado.

SEGURANÇA DO PIX
A chave PIX de telefone não foi inserida no código público. Configure o recebimento por um provedor de pagamento; nunca publique chave secreta ou credenciais no JavaScript do site.
