# Próxima etapa: PIX automático e entrega segura

A loja incluída é uma vitrine funcional com catálogo, filtros e carrinho local. O botão de checkout está intencionalmente em modo de demonstração.

Para automatizar a venda, você precisará:
1. De um provedor de pagamento que gere cobranças PIX e envie notificações (webhooks) quando o pagamento for confirmado.
2. De uma função de servidor para criar a cobrança. A chave secreta fica em variáveis de ambiente do Netlify — NUNCA no HTML ou JavaScript público.
3. De um webhook que valide a notificação consultando o provedor, confirme o valor e o estado do pagamento e só então libere o produto.
4. De armazenamento privado para os arquivos `.rbxm` / `.rbxmx`, com links temporários ou entrega controlada. Não use links públicos permanentes para produtos pagos.

Não basta a página de “pagamento aprovado” para liberar um arquivo: essa página pode ser aberta sem pagar. A confirmação precisa vir do servidor/provedor.

Como você está começando pelo celular, primeiro publique e teste a vitrine. Depois configure o pagamento com ajuda do responsável pela conta do provedor, se necessário.
